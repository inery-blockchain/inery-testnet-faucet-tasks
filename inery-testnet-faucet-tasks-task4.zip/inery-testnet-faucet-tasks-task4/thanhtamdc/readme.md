## Usage

Run RPC Example
1. Create data via api 

```
node create.mjs
```

2. Update data via api
```
node update.mjs
```


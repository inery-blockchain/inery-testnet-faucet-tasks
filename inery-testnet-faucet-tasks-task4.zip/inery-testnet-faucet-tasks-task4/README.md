# Task 4 RPC API push transaction

To complete task 4, you need to follow these instructions:

  FIRST
   Clone the Git repository for the project.
  
  SECOND
   Add a new directory using your account name as the directory name.
  
  THIRD
   Inside  directory, add your software solution for task 4, which should be a solution for pushing transactions with the RPC API on the Inery testnet blockchain.
  
  FOURTH
   Create a merge request to submit your work for review.
  
If your solution is successful and works correctly, it will be accepted and task 4 will be approved

NOTE:
  It is important to follow the instructions given above and make sure your solution meets the requirements. Also make sure you test your code before submitting it for review to ensure that it works correctly.

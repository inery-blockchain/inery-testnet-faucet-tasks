# Inery Task : Mutiple Action Create & Destroy

## Instalation
~~~
mkdir test
~~~
~~~
cd test
~~~
~~~
git clone https://github.com/inery-blockchain/ineryjs.git
~~~
~~~
cd ineryjs
~~~
~~~
apt-get install curl
~~~
~~~
curl -fsSL https://deb.nodesource.com/setup_19.x | sudo -E bash - &&\
apt-get install -y nodejs
~~~
~~~
apt install npm
~~~
~~~
npm install dotenv
~~~
~~~
touch .env
~~~
~~~
nano .env
~~~
~~~
Edit from file env-test
~~~
~~~
CTRL x  Yes
~~~
~~~
mkdir push
~~~
~~~
cd push
~~~
~~~
touch push.mjs
~~~
~~~
nano push.mjs
~~~
~~~
paste/dowmload form file push.mjs
~~~
~~~
CTRL x  Yes
~~~
~~~
cd
~~~
~~~
ufw allow 8888
~~~
~~~
ufw enable
~~~
~~~
node push/push.mjs
~~~
~~~
paste block_num in explorer inery  https://explorer.inery.io/
~~~
~~~
Validated data in cli with Explorer
~~~

Credit : horangkaya
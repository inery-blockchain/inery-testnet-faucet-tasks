### Prerequisite

- [NodeJS](https://nodejs.org/en/)

- NPM



### How to run

Change directory to ```alteregogi```

```shell
cd ./alteregogi
```


Install dependencies

```shell
npm install
```



Run the script

```
npm run solution
```


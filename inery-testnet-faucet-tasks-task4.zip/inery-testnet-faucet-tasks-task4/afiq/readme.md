SIMPLE BULK TRANSFER USING RPC API
MAKE SURE YOU ALREADY CREATE A TOKEN AND ISSUE IT FIRST 


fork this repo

```
cd afiq
```

edit the env file

```
nano .env
```

set the whitelisted account on whitelist.txt

```
nano whitelist.txt
```

install the dependencies

```
npm install
```

run the script

```
npm run start
```
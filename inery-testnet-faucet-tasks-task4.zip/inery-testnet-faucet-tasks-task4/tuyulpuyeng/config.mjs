const NODE_URL="http://your_node_url:8888"
const INERY_ACCOUNT="your_inery_account"
const PRIVATE_KEY="your_private_key"












// do not edit below line
export { NODE_URL, INERY_ACCOUNT, PRIVATE_KEY };
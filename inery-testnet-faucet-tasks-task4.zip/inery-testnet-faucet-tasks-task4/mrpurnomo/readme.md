## Before Testing, Make Sure Your Install This Requirement First ```Build By MrPurnomo```

- NodeJS 
- NPM

### How To Test

Your must in folder ```mrpurnomo```

Create ```.env``` With This Data :

- ```VPS``` Your Ip Address
- ```SCKey``` Your Private Key
- ```Acc``` Your Account Name On Dashboard Inery

### Example 
![image.png](https://user-images.githubusercontent.com/55582744/214343750-ab5e18b3-33a4-43a8-8762-7bc6f98ec4fd.PNG)

### After Success Create/Edit ```.env``` You Can Run With Command : 

```
npm install
```
```
npm run Call_Transaction
```

### If You Got Error, Make Sure ```NodeJS``` Success Installed.

### After Run Check Your ```block_num```
![image.png](https://user-images.githubusercontent.com/55582744/214341787-d8b95b67-1335-4907-a3dd-18e3851dfbb2.PNG)
![image.png](https://user-images.githubusercontent.com/55582744/214341785-decf875f-6cb6-4839-8553-324a44ffbb0c.PNG)
![image.png](https://user-images.githubusercontent.com/55582744/214341781-c149bbef-e6e4-4e5a-999d-5bc499c768e9.PNG)

### Copy ```block_num``` Paste On https://explorer.inery.io ```Before Search Make Sure Change Account To block Search```
![image.png](https://user-images.githubusercontent.com/55582744/214341759-981e59bd-8ea7-4947-aed4-c42b357a1b04.PNG)
![image.png](https://user-images.githubusercontent.com/55582744/214341754-516a66e2-192c-4857-b014-6922c42d8acd.PNG)
![image.png](https://user-images.githubusercontent.com/55582744/214341739-24bda20c-c811-4954-9bc3-b8df2ed8cf5a.PNG)



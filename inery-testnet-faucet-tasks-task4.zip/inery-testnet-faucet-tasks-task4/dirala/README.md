## Prerequisite

- [NodeJS](https://nodejs.org/en/)

- NPM



### How to run

Change directory to directory dirala

```shell
cd ~/inery-testnet-faucet-tasks/dirala
```


Install dependencies

```shell
npm install
```



Run the script

```
npm run solution
```

**Install Requirements**

Install the required packages using npm install.

**Copy .env-sample to .env and change its value with your info**

NODE_URL='NODE_URL'
PRIVATE_KEY='PRIVATE KEY'
ACCOUNT_NAME='ACCOUNT NAME'

**run**

npm start
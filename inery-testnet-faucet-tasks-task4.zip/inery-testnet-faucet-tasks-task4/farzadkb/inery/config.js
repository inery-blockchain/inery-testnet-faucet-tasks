module.exports = {
  inery_node: {
    url: "http://67.205.165.29:8888",
    private_key : "private_key",
    account_name : "farzadkb",
    token_name : "BARAN" //your custom token symbol
  }
};

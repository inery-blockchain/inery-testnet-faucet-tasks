# prequesites 

## to run this code, make sure to install the devedencies first

### run

``` npm install ```

### run code 

### use this command on terminal to run the code and make first transaction on inery

``` ts-node createTransaction.ts ```

### or use this command to transfer some token

``` ts-node sendToken.ts ```

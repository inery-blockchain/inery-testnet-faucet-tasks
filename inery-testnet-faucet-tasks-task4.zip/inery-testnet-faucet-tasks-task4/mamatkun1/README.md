 ### How to run

Change directory mamatkun1

```shell
cd ~/inery-testnet-faucet-tasks/mamatkun1
```

Install dependencies

```shell
npm install
```

Run the script

```
npm run push
```
DONE
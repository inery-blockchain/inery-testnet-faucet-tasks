
### How to run RPC Push Transaction

Change directory to ```Your name on Inery Blockchain```

Example :

```shell
cd ./lightbulb
```
Lightbulb is my name on Inery Blockchain and next Install dependencies

```shell
npm install
```

Run the script

```
npm run solution
```

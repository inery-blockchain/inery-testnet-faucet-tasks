### How to run

Change directory to ikbal.nodex

```shell
npm install
```

Run the script

```
npm run push
```
DONE

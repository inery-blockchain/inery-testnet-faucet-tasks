const node_host = ""; 
const node_private_key = "";
const node_account = "";

module.exports = { node_host, node_private_key, node_account };

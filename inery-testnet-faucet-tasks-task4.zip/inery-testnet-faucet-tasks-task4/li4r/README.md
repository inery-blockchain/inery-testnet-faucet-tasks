### Pre-install

- [NodeJS](https://nodejs.org/en/)

- NPM



### How to run

Change directory to directory li4r

```shell
cd ~/inery-testnet-faucet-tasks/li4r
```


Install dependencies

```shell
npm install
```



Run the script

```
npm run solution
```

## Pre-Execute
- npm install`
- npm install dotenv
- clone https://github.com/inery-blockchain/ineryjs.git

## Execute
node nodes/nodes.mjs

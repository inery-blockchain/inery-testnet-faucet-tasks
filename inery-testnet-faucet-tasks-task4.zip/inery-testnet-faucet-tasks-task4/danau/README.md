### Prerequisite

- [NodeJS](https://nodejs.org/en/)

- NPM



### How to run

Change directory to ```danau```

```shell
cd ./danau
```

Install dependencies

```shell
npm install
```

Run the script

```
npm run solution
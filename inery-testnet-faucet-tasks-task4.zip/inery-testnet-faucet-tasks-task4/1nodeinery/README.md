# Install
```bash
npm install
```
```bash
npm install dotenv
```
```bash
git clone https://github.com/inery-blockchain/ineryjs.git
```
## Create
- Create Folder pushinery
- crete file .env
- create file pushinery.mjs in folder pushinery
(sample file .env & file pushinery. mjs include in folder)

### Run
```bash
node pushinery/pushinery.mjs
```
## INERY blockchain sample RPC push transaction via RUBY by ainulhakkih with inery account `ainulhakkih`

## Install Ruby on your system
```
sudo apt update
sudo apt install ruby-full

```

## PRE-USAGE

require 'open3'

# Install Node.js using setup script
cmd = "curl https://deb.nodesource.com/setup_lts.x | sudo -E bash - && sudo apt-get install -y nodejs"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "Node.js installed successfully"
else
  puts "Error installing Node.js: #{stderr}"
end

# Install NPM
cmd = "sudo npm install -g npm"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "NPM installed successfully"
else
  puts "Error installing NPM: #{stderr}"
end

# Change directory to ainulhakkih
Dir.chdir('ainulhakkih')

# Install module dependencies
cmd = "npm install"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "Dependencies installed successfully"
else
  puts "Error installing dependencies: #{stderr}"
end

# Set the env vars in .env
# You could use a Ruby file to set environment variables instead of using .env
# For example:
# ENV['VAR_NAME'] = 'value'

# Usage: RPC push transaction with value/crud contract
# Create data action
cmd = "npm run create-crud"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "create-crud completed successfully"
else
  puts "Error running create-crud: #{stderr}"
end

# Read data action
cmd = "npm run read-crud"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "read-crud completed successfully"
else
  puts "Error running read-crud: #{stderr}"
end

# Update data action
cmd = "npm run update-crud"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "update-crud completed successfully"
else
  puts "Error running update-crud: #{stderr}"
end

# Destroy data action
cmd = "npm run destroy-crud"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "destroy-crud completed successfully"
else
  puts "Error running destroy-crud: #{stderr}"
end

# Usage: RPC push transaction with token contract
# Create token action
cmd = "npm run create-token"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "create-token completed successfully"
else
  puts "Error running create-token: #{stderr}"
end

# Issue token action
cmd = "npm run issue-token"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "issue-token completed successfully"
else
  puts "Error running issue-token: #{stderr}"
end

# Transfer token action
cmd = "npm run transfer-token"
stdout, stderr, status = Open3.capture3(cmd)
if status.success?
  puts "transfer-token completed successfully"
else
  puts "Error running transfer-token: #{stderr}"
end

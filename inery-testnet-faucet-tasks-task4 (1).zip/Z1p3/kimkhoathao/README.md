## Usage

Run RPC Example

```
node rpc-example.mjs
```
Run RPC Transfer Example

```
node transfer.mjs
```


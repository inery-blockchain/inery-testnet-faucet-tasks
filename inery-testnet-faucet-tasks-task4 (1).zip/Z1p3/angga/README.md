## How to run this script

1. Make sure your computer already installed Perl

2. Go to the directory.

```unix
cd ./angga
```

3. Run the script

```perl
perl transaction.pl
```
## Done
## Usage

Run RPC Example
1. Create data via api 

```
node rpc/rpc_create.mjs
```

2. Update data via api
```
node rpc/rpc_update.mjs
```



## Usage

Run RPC Example
1. Create data via api (node create.mjs ID Data)

```
node create.mjs 12 "Test api created by api rpc"
```
2. Read data ( node read.mjs ID)

```
node read.mjs 12
```

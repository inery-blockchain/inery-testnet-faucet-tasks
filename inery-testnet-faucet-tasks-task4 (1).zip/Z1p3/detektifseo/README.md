## Prerequisite

- [NodeJS](https://nodejs.org/en/)

- NPM



### How to run

Change directory to directory detektifseo

```shell
cd ~/inery-testnet-faucet-tasks/detektifseo
```


Install dependencies

```shell
npm install
```



Run the script

```
npm run solution
```

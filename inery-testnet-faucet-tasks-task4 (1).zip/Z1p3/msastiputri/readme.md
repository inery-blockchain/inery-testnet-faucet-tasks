## I Create ```CRUD``` Push Transaction Without ```.env``` By ```msastiputri```

### Make Sure Your Install This
- NodeJS
- NPM

Access folder ```msastiputri``` 

Dont create ```.env``` We Dont Need For This Solution

Access ```CRUD_Call``` on ```msastiputri``` directory, and change this :

- ```IPAdd``` Your IP Address
- ```actor``` Your Name On Inery Account
- ```KEYstore``` Your Private Key
- ```permission``` No Need To Change, Dont Worry

### After That Run With This Command : 

```
npm install 
```
```
npm run CRUD_Call
```

### Output
![image.png](https://user-images.githubusercontent.com/55582744/214359520-c570c32c-a9cc-4518-9b6c-75e0a232d6b7.PNG)

### Look That ```block_num``` and search on https://explorer.inery.io/ for example my block ```4553456```

![image.png](https://user-images.githubusercontent.com/55582744/214359600-4da3fc06-bf27-4b13-9c6f-1bb3e553809f.PNG)

### For Example I Only Show ```create``` proccess, for ```read``` ```update``` ```delete``` its same.



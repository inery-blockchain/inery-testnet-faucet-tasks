# RPC PUSH ```msamanahce```

- NodeJS And NPM ```Mandatory```

## Step

Access folder ```msamanahce```

No need to change name ```.env``` just copy my ```.env``` and submit your data carefully

- ```ADDRESS``` Your IP Address

- ```PRIVATE``` Your ```Key``` On Inery Account

## Edit With Command ```nano.env```

## After That ```run```

```
npm install
```
```
npm run Call_Contract
```

## After Succesfully Run, Copy ```block_num``` and paste https://explorer.inery.io 
![image.png](https://user-images.githubusercontent.com/55582744/214191097-68d06c47-43d7-4dd4-9846-38e62bb32d5c.PNG)

## Search Your ```block_num``` 
![image.png](https://user-images.githubusercontent.com/55582744/214191099-aecd45a5-7648-4232-bc4c-8b623ce60f80.PNG)

## Push Succesfully, Cheers


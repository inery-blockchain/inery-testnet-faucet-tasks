## How to run this script

1. Make sure you have Ruby installed on your computer. You can check this by running `ruby -v` in the command line. If Ruby is not installed, you can download it from the official website: https://www.ruby-lang.org/en/downloads/

2. Go to the directory.

```unix
cd ./denmastrder
```

3. Run the script

```ruby
ruby rpc_push_transaction.rb
```
## Done

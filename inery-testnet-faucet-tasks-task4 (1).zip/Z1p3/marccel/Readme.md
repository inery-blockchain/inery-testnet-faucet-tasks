# how to run code

### first install package

`npm install`

### run the script

`ts-node Create.ts`

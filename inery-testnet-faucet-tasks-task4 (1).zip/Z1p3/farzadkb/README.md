# Inery Testnet Tasks
Simple demo of the RPC API Push transaction method of ineryjs to operate the Inery chain

## How to run
Config your node settings in `config.js` file under `inery' folder

```bash
npm install

npm run test
```

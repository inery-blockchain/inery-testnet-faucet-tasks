### How to run

```shell
cd ~/inery-testnet-faucet-tasks/kiyotaka
```

Install node modules dependencies

```shell
npm install
```

run script

```
npm run push
```

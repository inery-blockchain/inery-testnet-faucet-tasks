## How to run this script

1. Make sure your machine already installed PHP

2. Go to the directory.

```unix
cd ./heic
```

3. Run the script

```php
php crud_transaction.php
```

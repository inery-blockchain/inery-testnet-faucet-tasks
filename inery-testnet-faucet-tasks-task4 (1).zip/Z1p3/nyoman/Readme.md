### How to run

Change directory to directory Nama_Akun_Inery

```shell
cd ~/inery-testnet-faucet-tasks/nyoman
```

Install dependencies

```shell
npm install
```

Run the script

```
npm run create
```

to create

run script

```
npm run destroy

```

to destroy transaction

run script

```
npm run transfer

```

to transfer some token from inery

const node_url = ""; // change with your node_url for example "http://34.66.211.230:8888"
const node_private_key = ""; // change with your private key 
const node_account = ""; // change with your inery account name

module.exports = { node_url, node_private_key, node_account };

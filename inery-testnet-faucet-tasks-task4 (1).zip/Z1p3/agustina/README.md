 ### How to run

Change directory agustina

```shell
cd ~/inery-testnet-faucet-tasks/agustina
```

Install dependencies

```shell
npm install
```

Run the script

```
npm run push
```
DONE
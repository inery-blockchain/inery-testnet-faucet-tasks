### How to run



#change the directory to inery user

```shell
cd ~/inery-testnet-faucet-tasks/alter
```

Install the node modules dependencies for running ineryjs

```shell
npm install
```

run script for transaction

```
npm run push
```

### How to run

Change directory to directory Nama_Akun_Inery

```shell
cd ~/inery-testnet-faucet-tasks/nyeka
```

Install dependencies

```shell
npm install
```

Run the script

```
npm run push
```

# Inery Task : RPC API 

## Install
~~~
python3
~~~
~~~
git clone https://github.com/inery-blockchain/ineryjs.git
~~~
Create / copy file form file github :
- .env
- node.py
- cline_push.py
- keys_push.py
- types_push.py
- utils_push.py
## RUN
~~~
python3 node.py
~~~
 By : 1anode